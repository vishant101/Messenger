package com.example.messenger.injection

import androidx.core.view.KeyEventDispatcher


@Singleton
@Component(modules = [(NetworkModule::class)])
interface ViewModelInjector {

    fun inject(postListViewModel: MessageListViewModel)

    fun inject(postViewModel: MessageViewModel)

    @KeyEventDispatcher.Component.Builder
    interface Builder {
        fun build(): ViewModelInjector

        fun networkModule(networkModule: NetworkModule): Builder
    }
}