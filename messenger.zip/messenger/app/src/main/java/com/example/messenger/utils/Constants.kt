package com.example.messenger.utils

const val BASE_URL: String = "https://jsonplaceholder.typicode.com"