package com.example.messenger.model

import androidx.room.Entity
import java.sql.Timestamp

@Entity
data class Message (
    val senderId: Int,
    val name: String,
    var messageText: String,
    var timestamp: Timestamp
)